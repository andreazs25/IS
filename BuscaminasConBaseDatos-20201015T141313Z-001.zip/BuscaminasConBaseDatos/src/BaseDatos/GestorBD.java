package BaseDatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import minesweeper.CatalogoJugadores;
import minesweeper.Jugador;

public class GestorBD {
	private String url = "jdbc:mysql://localhost:3306/";
	private String user = "root";
	private String passwd = "1234";
	private String driver = "com.mysql.jdbc.Driver";

	private Connection conn;

	public GestorBD() {
		try {
			Class.forName(this.driver).newInstance();
			this.conn = (Connection) DriverManager.getConnection(this.url,
					this.user, this.passwd);
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
	}

	public void setNuevoUsuario(String usuario, int puntuacion, int nivel) {
		String query = "INSERT INTO raking.ranking (usuario,puntuacion,nivel) VALUES ('"
				+ usuario + "', " + puntuacion + "," + nivel + ");";
		System.out.println("     DB query: " + query);
		try {
			Statement st = this.conn.createStatement();
			st.executeUpdate(query);
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
	}

	public void setJugadorUpdate(String usuario, int puntuacion, int nivel) {

		String query = "UPDATE raking.ranking SET usuario='" + usuario
				+ "',puntuacion='" + puntuacion + "', nivel='" + nivel
				+ "' WHERE usuario='" + usuario + "'";

		System.out.println("     DB query: " + query);
		try {
			Statement st = this.conn.createStatement();
			st.executeUpdate(query);
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
	}
	public boolean esta(String usuario) {
		boolean esta = false;
		String query = "SELECT * FROM raking.ranking WHERE usuario='" + usuario + "'"; 
		try {
			Statement st = this.conn.createStatement();
			ResultSet res = st.executeQuery(query);

			while (res.next()) {
				return true;
			}
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
		return esta;

	}

	public void getAllRanking() {
		String query = "SELECT * FROM raking.ranking order by puntuacion DESC;";
		System.out.println("     DB query: " + query);
		try {
			Statement st = this.conn.createStatement();
			ResultSet res = st.executeQuery(query);
			while (res.next()) {
				CatalogoJugadores.getCatalogoJugadores().addJugador(
						new Jugador(res.getString("usuario"), res
								.getInt("puntuacion"), res.getInt("nivel")));
			}
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}

	}
}
