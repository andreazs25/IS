package minesweeper;

public class CasillaConMina extends Casilla {

	public CasillaConMina() {}

	@Override
	public void descubrir() {
		super.descubrir();

	}

}
