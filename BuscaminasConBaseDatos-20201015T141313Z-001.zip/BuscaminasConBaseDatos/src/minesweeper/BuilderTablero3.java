package minesweeper;

public class BuilderTablero3 extends BuilderTablero {

	public BuilderTablero3() {
	}

	@Override
	public void buildDimensionesTablero() {
		this.tablero = new Tablero(12, 25, 75);
	}
}
