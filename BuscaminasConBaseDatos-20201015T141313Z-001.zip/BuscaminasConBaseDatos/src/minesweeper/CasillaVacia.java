package minesweeper;

public class CasillaVacia extends Casilla {

	public CasillaVacia() {
	}

	@Override
	public void descubrir() {
		super.descubrir();

	}

}
