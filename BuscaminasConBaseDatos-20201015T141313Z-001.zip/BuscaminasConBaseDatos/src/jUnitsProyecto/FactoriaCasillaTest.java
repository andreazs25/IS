package jUnitsProyecto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import minesweeper.Casilla;
import minesweeper.CasillaConMina;
import minesweeper.CasillaConNumero;
import minesweeper.CasillaVacia;
import minesweeper.FactoriaCasilla;

public class FactoriaCasillaTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCrearCasilla() {
		// Creamos una casilla vacia
		Casilla c1 = FactoriaCasilla.getFactoriaCasilla().crearCasilla(0);
		// Creamos una casilla con n�mero
		Casilla c2 = FactoriaCasilla.getFactoriaCasilla().crearCasilla(1);
		// Creamos una casilla con mina
		Casilla c3 = FactoriaCasilla.getFactoriaCasilla().crearCasilla(2);
		
		// Vemos si ha creado la casilla pedida
		assertTrue(c1 instanceof CasillaVacia);
		assertTrue(c2 instanceof CasillaConNumero);
		assertTrue(c3 instanceof CasillaConMina);
	}

}
