package jUnitsProyecto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import minesweeper.Buscaminas;
import minesweeper.CasillaConNumero;

public class TableroTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDescubrirCasillaYPonerCasillaEnPosicion() {
		// Ponemos una casilla con numero en el tablero
		Buscaminas.getBuscaminas().getablero().ponerCasillaEnPosicion(1, 1, 1);
		// Comprobamos que es con numero
		assertTrue(Buscaminas.getBuscaminas().getablero().obtenerCasilla(1, 1) instanceof CasillaConNumero);
		//Descubrimos la casilla con mina
		Buscaminas.getBuscaminas().getablero().descubrirCasilla(1, 1);
		// Comprobamos que esta descubierta
		assertTrue(Buscaminas.getBuscaminas().getablero().obtenerCasilla(1, 1).esDercubierta());
		//El resto lo probamos por consola e interfaz gr�fica
		
	}

	@Test
	public void testMarcarDesmarcarCasilla() {
		// Construimos un buscaminas
		Buscaminas.getBuscaminas().construirTableroPorNivel(1);
		//Marcamos una casilla de la esquina (0,0)
		Buscaminas.getBuscaminas().getablero().marcarDesmarcarCasilla(0, 0);
		// Comprobamos que esta marcada
		assertTrue(Buscaminas.getBuscaminas().getablero().obtenerCasilla(0, 0).esMarcada());
		//La desmarcamos
		Buscaminas.getBuscaminas().getablero().marcarDesmarcarCasilla(0, 0);
		// Comprobamos
		assertFalse(Buscaminas.getBuscaminas().getablero().obtenerCasilla(0, 0).esMarcada());
		//Hacemos lo mismo con otra casilla
		Buscaminas.getBuscaminas().getablero().marcarDesmarcarCasilla(4, 4);
		assertTrue(Buscaminas.getBuscaminas().getablero().obtenerCasilla(4, 4).esMarcada());
		Buscaminas.getBuscaminas().getablero().marcarDesmarcarCasilla(4, 4);
		assertFalse(Buscaminas.getBuscaminas().getablero().obtenerCasilla(4, 4).esMarcada());
	}
}
