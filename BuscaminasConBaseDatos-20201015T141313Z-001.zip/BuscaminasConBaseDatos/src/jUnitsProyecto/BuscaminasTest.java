package jUnitsProyecto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import minesweeper.Buscaminas;

public class BuscaminasTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testConstruirTableroPorNivel() {
		//Creo un buscaminas de nivel 1
		Buscaminas.getBuscaminas().construirTableroPorNivel(1);
		assertNotNull(Buscaminas.getBuscaminas().obtenerCasilla(0, 0));
		assertNotNull(Buscaminas.getBuscaminas().obtenerCasilla(0, 6));
		assertNotNull(Buscaminas.getBuscaminas().obtenerCasilla(6, 0));
		assertNotNull(Buscaminas.getBuscaminas().obtenerCasilla(4, 4));
		
		//Creo un buscaminas de nivel 2
		Buscaminas.getBuscaminas().construirTableroPorNivel(2);
		assertNotNull(Buscaminas.getBuscaminas().obtenerCasilla(0, 10));
		assertNotNull(Buscaminas.getBuscaminas().obtenerCasilla(9, 0));
		
		//Creo un buscaminas de nivel 3
		Buscaminas.getBuscaminas().construirTableroPorNivel(3);
		assertNotNull(Buscaminas.getBuscaminas().obtenerCasilla(0, 22));
		assertNotNull(Buscaminas.getBuscaminas().obtenerCasilla(11, 0));
	}

}
