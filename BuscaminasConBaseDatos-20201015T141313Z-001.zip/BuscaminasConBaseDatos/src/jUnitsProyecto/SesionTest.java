package jUnitsProyecto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import minesweeper.CatalogoJugadores;
import minesweeper.Sesion;

public class SesionTest {
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIniciarSesion() {
		//Inicio sesion con nombre Sergio y nivel 1
		Sesion.getSesion().iniciarSesion("Sergio", 1);
		//Compruebo el nivel
		assertEquals(1, Sesion.getSesion().getNivel());
		//Compruebo que me a a�adido al jugador
		assertTrue(CatalogoJugadores.getCatalogoJugadores().estaJ("Sergio"));
		//Compruebo que el jugador de la sesion es el correcto
		assertEquals(Sesion.getSesion().getJugador().getNombre(),"Sergio");
		//Inicio sesion con otro jugador
		Sesion.getSesion().iniciarSesion("Juan", 2);
		//Compruebo que el jugador anterior sige exisitendo y el actual
		assertTrue(CatalogoJugadores.getCatalogoJugadores().estaJ("Sergio"));
		assertTrue(CatalogoJugadores.getCatalogoJugadores().estaJ("Juan"));
		//Ha cambiado el nivel y el jugador
		assertEquals(2, Sesion.getSesion().getNivel());
		assertEquals(Sesion.getSesion().getJugador().getNombre(),"Juan");
	}
}
