package jUnitsProyecto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import minesweeper.Jugador;
import minesweeper.ListaJugadores;

public class ListaJugadoresTest {


	private ListaJugadores lista;
	private Jugador j1;
	
	@Before
	public void setUp() throws Exception {
		lista= new ListaJugadores();
		j1 = new Jugador("Sergio");
	}

	@After
	public void tearDown() throws Exception {
		lista = null;
	}

	@Test
	public void testAnadirJugadorPorNombreYEstaJ() {
		//A�ado un jugador j2 
		Jugador j2 = lista.anadirJugadorPorNombre("Pepe");
		//Compruebo el nombre
		assertEquals(j2.getNombre(), "Pepe");
		//Compruebo que esta
		assertNotNull(lista.estaJ("Pepe"));
		//Un jugador que no exsta
		assertNull(lista.estaJ("Morrissey"));
		//A�ado otro jugador
		Jugador j3 = lista.anadirJugadorPorNombre("Nacho");
		//Compruebo que esta
		assertNotNull(lista.estaJ("Nacho"));
		//A�ado un jugador que ya existe
		Jugador j4 = lista.anadirJugadorPorNombre("Nacho");
		//Comparo los jugadores
		assertEquals(j3,j4);
	}

	@Test
	public void testGetListaRanking() {
		//A�ado dos jugadore y obtengo la lista del ranking ordenados por puntacion
		lista.anadirJugadorPorNombre("Sergio");
		lista.anadirJugadorPorNombre("Pepe");
		ListaJugadores lista2 = lista.getListaRanking(1);
	}

	@Test
	public void testOrdenaPorPuntuacion() {
		
	}

}
