package ventanasProyecto;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import minesweeper.CatalogoJugadores;
import minesweeper.Sesion;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;

import javax.swing.ImageIcon;
import javax.swing.JTextArea;

public class DialogGanada extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JButton botonReiniciar;
	private JButton botonInicio;
	private JButton botonSalir;
	private JLabel textoGanado;
	private JLabel luna;
	private JLabel sofa;
	private JTextArea texto;

	/**
	 * Create the dialog.
	 */
	public DialogGanada() {
		setBounds(700, 100, 450, 375);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		contentPanel.add(getBotonReiniciar());
		contentPanel.add(getBotonInicio());
		contentPanel.add(getBotonSalir());
		contentPanel.add(getTextoGanado());
		contentPanel.add(getLuna());
		contentPanel.add(getSofa());
		contentPanel.add(getTexto());
		setVisible(true);
	}
	private JButton getBotonReiniciar() {
		botonReiniciar = new JButton("Reiniciar");
		botonReiniciar.setBounds(58, 290, 97, 25);
		botonReiniciar.addActionListener(new Controlador());
		botonReiniciar.setActionCommand("jugar");
		return botonReiniciar;
	}
	private JButton getBotonInicio() {
		botonInicio = new JButton("Inicio");
		botonInicio.setBounds(166, 290, 97, 25);
		botonInicio.addActionListener(new Controlador());
		botonInicio.setActionCommand("inicio");
		return botonInicio;
	}
	private JButton getBotonSalir() {
		botonSalir = new JButton("Salir");
		botonSalir.setBounds(275, 290, 97, 25);
		botonSalir.addActionListener(new Controlador());
		botonSalir.setActionCommand("salir");
		return botonSalir;
	}
	private JLabel getTextoGanado() {
		textoGanado = new JLabel("Enhorabuena!! Has ganado la partida");
		textoGanado.setFont(new Font("Tahoma", Font.BOLD, 16));
		textoGanado.setBounds(12, 0, 327, 56);
		return textoGanado;
	}
	private JLabel getLuna() {
		luna = new JLabel("");
		luna.setIcon(new ImageIcon(DialogGanada.class.getResource("/imagenes/luna.png")));
		luna.setBounds(353, -45, 186, 139);
		return luna;
	}
	private JLabel getSofa() {
		sofa = new JLabel("");
		sofa.setIcon(new ImageIcon(DialogGanada.class.getResource("/imagenes/sit.png")));
		sofa.setBounds(0, 229, 274, 73);
		return sofa;
	}
	
	private JTextArea getTexto() {
		texto = new JTextArea();
		texto.setBounds(58, 42, 314, 235);
		texto.setEditable(false);
		texto.setText(CatalogoJugadores.getCatalogoJugadores().obtenerMejoresJugadores(10, Sesion.getSesion().getNivel()));
		return texto;
	}
	
	private class Controlador extends WindowAdapter implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent ae) {
			String action = ae.getActionCommand();
			if (action.equals("jugar")) {
				dispose();
				Sesion.getSesion().actualizarTablero();
				new VentanaBuscaminas(Sesion.getSesion().getNivel());
			} else if (action.equals("salir")) {
				dispose();
				System.exit(0);
			} else if (action.equals("inicio")) {
				dispose();
				new VentanaInicial();
			}
		}
	}
}
