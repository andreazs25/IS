/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanasProyecto;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import minesweeper.Sesion;

public class DialogPerdido extends javax.swing.JDialog {

    private JPanel contentPane;
    private JButton btnReintentar;
    private JButton btnInicio;
    private JButton btnSalir;
    private JLabel lblHasPerdidoLa;
    private JLabel label;
    private JLabel label_1;
    private java.awt.Frame padre;

    /**
     * Creates new form dialog
     */
    public DialogPerdido(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        padre = parent;
        this.setTitle("Partida perdida");
        setResizable(false);
        setDefaultCloseOperation(0);
        setBounds(700, 100, 450, 259);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        contentPane.add(getBtnReintentar());
        contentPane.add(getBtnInicio());
        contentPane.add(getBtnSalir());
        contentPane.add(getLblHasPerdidoLa());
        contentPane.add(getLabel());
        contentPane.add(getLabel_1());
        setVisible(true);
    }

    // Bot�n reintentar
    private JButton getBtnReintentar() {
        btnReintentar = new JButton("Reintentar");
        btnReintentar.setBounds(62, 162, 97, 25);
        btnReintentar.addActionListener(new Controlador());
        btnReintentar.setActionCommand("reiniciar");
        return btnReintentar;
    }

    // Bot�n inicio
    private JButton getBtnInicio() {
        btnInicio = new JButton("Inicio");
        btnInicio.setBounds(171, 162, 97, 25);
        btnInicio.addActionListener(new Controlador());
        btnInicio.setActionCommand("inicio");
        return btnInicio;
    }

    // Bot�n para salir
    private JButton getBtnSalir() {
        btnSalir = new JButton("Salir");
        btnSalir.setBounds(280, 162, 97, 25);
        btnSalir.addActionListener(new Controlador());
        btnSalir.setActionCommand("salir");
        return btnSalir;
    }

    // Texto informativo
    private JLabel getLblHasPerdidoLa() {
        lblHasPerdidoLa = new JLabel("Has perdido la partida");
        lblHasPerdidoLa.setFont(new Font("Franklin Gothic Book", Font.BOLD, 17));
        lblHasPerdidoLa.setBounds(62, 99, 263, 69);
        return lblHasPerdidoLa;
    }

    // Imagen 1
    private JLabel getLabel() {
        label = new JLabel("");
        label.setIcon(new ImageIcon(DialogPerdido.class.getResource("/imagenes/muerte.png")));
        label.setBounds(259, 13, 135, 148);
        return label;
    }

    // Imagen 2
    private JLabel getLabel_1() {
        label_1 = new JLabel("");
        label_1.setIcon(new ImageIcon(DialogPerdido.class.getResource("/imagenes/vela.png")));
        label_1.setBounds(-18, 0, 251, 125);
        return label_1;
    }

  
// Controlador
	private class Controlador extends WindowAdapter implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent ae) {
			String action = ae.getActionCommand();
			if (action.equals("reiniciar")) {
				dispose();
				Sesion.getSesion().actualizarTablero();
				new VentanaBuscaminas(Sesion.getSesion().getNivel());
			} else if (action.equals("salir")) {
				dispose();
				System.exit(0);
			} else if (action.equals("inicio")) {
				dispose();
				new VentanaInicial();
			}
			padre.dispose();
		}
	}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
