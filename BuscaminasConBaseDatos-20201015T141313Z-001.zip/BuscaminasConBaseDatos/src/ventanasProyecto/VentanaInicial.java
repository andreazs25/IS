package ventanasProyecto;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import minesweeper.Buscaminas;
import minesweeper.Sesion;

import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Rectangle;
import java.awt.Component;
import javax.swing.SwingConstants;

public class VentanaInicial extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JComboBox comboBox;
	private JLabel pedirNombre;
	private JLabel pedirNivel;
	private JButton btnEmpezar;
	private JLabel lblMinesweeper;
	private JButton btnSalir;
	private JLabel fondo;
	private JButton btnRanking;

	public VentanaInicial() {
		setResizable(false);
		this.setTitle("INICIO");
		this.setIconImage(new ImageIcon(getClass().getResource("/imagenes/icon.png")).getImage());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(700, 100, 398, 388);
		contentPane = new JPanel();
		contentPane.setBorder(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getBtnRanking());
		contentPane.add(getTextField());
		contentPane.add(getComboBox());
		contentPane.add(getPedirNombre());
		contentPane.add(getPedirNivel());
		contentPane.add(getBtnEmpezar());
		contentPane.add(getLblMinesweeper());
		contentPane.add(getBtnSalir());
		contentPane.add(getFondo());
		setVisible(true);
	}

	// Donde introduce el usuario su nombre
	public JTextField getTextField() {
		textField = new JTextField();
		textField.setBounds(194, 123, 143, 22);
		textField.setColumns(10);
		return textField;
	}

	// Caja para pedir el nivel: 1, 2 o 3
	private JComboBox getComboBox() {
		comboBox = new JComboBox();
		comboBox.setBounds(258, 158, 64, 22);
		// a�ado los 3 niveles posibles
		comboBox.addItem("Nivel 1");
		comboBox.addItem("Nivel 2");
		comboBox.addItem("Nivel 3");
		return comboBox;
	}

	// Texto que pide el nombre del usuario
	private JLabel getPedirNombre() {
		pedirNombre = new JLabel("Introduzca su nombre:");
		pedirNombre.setOpaque(true);
		pedirNombre.setFont(new Font("Tahoma", Font.BOLD, 13));
		pedirNombre.setBounds(34, 123, 153, 22);
		return pedirNombre;
	}

	// Texto que pide el nivel: 1, 2 o 3
	private JLabel getPedirNivel() {
		pedirNivel = new JLabel("Eliga el nivel del juego (de 1 a 3): ");
		pedirNivel.setOpaque(true);
		pedirNivel.setFont(new Font("Tahoma", Font.BOLD, 13));
		pedirNivel.setBounds(34, 158, 218, 22);
		return pedirNivel;
	}

	// Bot�n para empezar a jugar
	private JButton getBtnEmpezar() {
		btnEmpezar = new JButton("Empezar");
		btnEmpezar.setBounds(34, 208, 85, 25);
		btnEmpezar.addActionListener(new Controlador());
		btnEmpezar.setActionCommand("empezar");
		return btnEmpezar;
	}

	// Titulo del Juego
	private JLabel getLblMinesweeper() {
		lblMinesweeper = new JLabel("MINESWEEPER");
		lblMinesweeper.setHorizontalAlignment(SwingConstants.CENTER);
		lblMinesweeper.setFont(new Font("Britannic Bold", Font.BOLD, 20));
		lblMinesweeper.setBounds(12, 89, 198, 34);
		return lblMinesweeper;
	}

	// Fondo de la aplicaci�n
	private JLabel getFondo() {
		fondo = new JLabel("");
		fondo.setIcon(new ImageIcon(VentanaInicial.class.getResource("/imagenes/fondo1.jpg")));
		fondo.setBounds(0, 0, 392, 353);
		return fondo;
	}

	// Boton de salir
	private JButton getBtnSalir() {
		btnSalir = new JButton("Salir");
		btnSalir.setBounds(143, 208, 85, 25);
		btnSalir.addActionListener(new Controlador());
		btnSalir.setActionCommand("salir");
		return btnSalir;
	}
	
	// Boton de Ranking
	private JButton getBtnRanking() {
		btnRanking = new JButton("Ranking");
		btnRanking.setBounds(252, 208, 85, 25);
		btnRanking.addActionListener(new Controlador());
		btnRanking.setActionCommand("ranking");
		return btnRanking;
	}
	
	public void verRanking(){
		new VentanaRanking(this,true);
	}

	private class Controlador extends WindowAdapter implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent ae) {
			String action = ae.getActionCommand();
			if (action.equals("empezar")) {
				// En caso de que el usuario introduzca algo en la casilla
				if (textField.getText().length() != 0) {
					// 1: Se inicia sesi�n con el nombre introducido por el
					// usuario y el nivel seleccionado
					// 2: Se construye un tablero del nivel apropiado
					// 3: Se genera una VentanaBuscaminas pasandole el nivel
					Sesion.getSesion().iniciarSesion(textField.getText(), comboBox.getSelectedIndex() + 1);
					Buscaminas.getBuscaminas().construirTableroPorNivel(comboBox.getSelectedIndex() + 1);
					new VentanaBuscaminas(comboBox.getSelectedIndex() + 1);
					dispose();
				}
				// En caso de que el usuario no introduzca nada en la casilla,
				// aparece una ventana de error
				else {
					new VentanaErrorSinNombre();
				}
			}
			// Boton de salir
			else if (action.equals("salir")) {
				dispose();
				System.exit(0);
			}
			
			else if (action.equals("ranking")) {
				verRanking();
			}
		}
	}
}
