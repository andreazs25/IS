package ventanasProyecto;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import minesweeper.Buscaminas;
import minesweeper.CatalogoJugadores;
import minesweeper.Sesion;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;

import javax.swing.JTextArea;
import javax.swing.ImageIcon;
import java.awt.Color;

public class VentanaRanking extends javax.swing.JDialog {

	private final JPanel contentPanel = new JPanel();
	private JLabel textRanking;
	private JLabel lblSeleccioneElNivel;
	private JComboBox comboBoxNivel;
	private JTextArea ranking;
	private JButton button;
	private JLabel lblNewLabel;
    private java.awt.Frame padre;
    private JButton btnAtras;

	public VentanaRanking(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        padre = parent;
		setResizable(false);
        setDefaultCloseOperation(0);
		this.setTitle("Ranking");
		setBounds(700, 100, 354, 435);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.add(getBtnAtras());
		contentPanel.setLayout(null);
		contentPanel.add(getTextRanking());
		contentPanel.add(getLblSeleccioneElNivel());
		contentPanel.add(getComboBoxNivel());
		contentPanel.add(getRanking());
		contentPanel.add(getButton());
		{
			lblNewLabel = new JLabel("");
			lblNewLabel.setIcon(new ImageIcon(VentanaRanking.class.getResource("/imagenes/fondo2.jpg")));
			lblNewLabel.setBounds(0, 0, 348, 400);
			contentPanel.add(lblNewLabel);
		}
		setVisible(true);
		
	}
	private JLabel getTextRanking() {
		textRanking = new JLabel("Ranking");
		textRanking.setForeground(Color.WHITE);
		textRanking.setFont(new Font("Stencil", Font.PLAIN, 16));
		textRanking.setBounds(53, 13, 159, 16);
		return textRanking;
	}
	
	
	private JLabel getLblSeleccioneElNivel() {
		lblSeleccioneElNivel = new JLabel("Seleccione nivel");
		lblSeleccioneElNivel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSeleccioneElNivel.setForeground(new Color(255, 255, 255));
		lblSeleccioneElNivel.setBounds(22, 39, 115, 16);
		return lblSeleccioneElNivel;
	}
	private JComboBox getComboBoxNivel() {
		comboBoxNivel = new JComboBox();
		comboBoxNivel.setBounds(133, 36, 34, 22);
		comboBoxNivel.addItem("1");
		comboBoxNivel.addItem("2");
		comboBoxNivel.addItem("3");
		return comboBoxNivel;
	}
	private JTextArea getRanking() {
		ranking = new JTextArea();
		ranking.setBounds(12, 64, 183, 323);
		ranking.setEditable(false);
		ranking.setText(CatalogoJugadores.getCatalogoJugadores().obtenerMejoresJugadores(18,1));
		return ranking;
	}
	
	private JButton getButton() {
		button = new JButton("");
		button.setIcon(new ImageIcon(VentanaRanking.class.getResource("/imagenes/botonn.png")));
		button.setBounds(173, 35, 25, 25);
		button.addActionListener(new Controlador());
		button.setActionCommand("nivel");
		return button;
	}
	
	private JButton getBtnAtras() {
		btnAtras = new JButton("Atras");
		btnAtras.setBounds(264, 8, 72, 25);
		btnAtras.addActionListener(new Controlador());
		btnAtras.setActionCommand("atras");
		return btnAtras;
	}
	
	private class Controlador extends WindowAdapter implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent ae) {
			String action = ae.getActionCommand();
			if (action.equals("nivel")) {
				ranking.setText(CatalogoJugadores.getCatalogoJugadores().obtenerMejoresJugadores(18, comboBoxNivel.getSelectedIndex() + 1));
			}
			else if (action.equals("atras")) {
				dispose();
			}
		}
	}
}
