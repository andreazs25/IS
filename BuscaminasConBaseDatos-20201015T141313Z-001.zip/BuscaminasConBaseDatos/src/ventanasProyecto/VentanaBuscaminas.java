package ventanasProyecto;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.SystemColor;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Insets;

import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import minesweeper.Buscaminas;
import minesweeper.Casilla;
import minesweeper.CasillaConMina;
import minesweeper.CasillaConNumero;
import minesweeper.Jugador;
import minesweeper.Sesion;

import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;

import BaseDatos.GestorBD;

public class VentanaBuscaminas extends JFrame implements Runnable, Observer {

	private JPanel contentPane;
	private JPanel panelBus;
	private JButton casillaB;
	private JPanel panelSup;
	private JButton carita, menu;
	private int f, c, numM;
	// matriz para meter la casillas
	private JButton[][] botones;
	private JLabel label;
	private JLabel desveladas;
	private JLabel minasQuedan;
	private Thread crono;
	// private javax.swing.JLabel tiempo = new javax.swing.JLabel();
	public static int fSelect = -1, cSelect = -1;

	public VentanaBuscaminas(int pNivel) {
		this.setTitle("BUSCAMINAS");
		setResizable(false);
		this.iniciar(pNivel);
		this.setIconImage(new ImageIcon(getClass().getResource(
				"/imagenes/icon.png")).getImage());
	}

	// Distinto n�mero de filas y columnas dependiendo del nivel introducido
	private void iniciar(int pNivel) {
		// nivel 1
		if (pNivel == 1) {
			f = 7;
			c = 10;
			numM = 10;
			setBounds(700, 100, 341, 369);
		}
		// nivel 2
		else if (pNivel == 2) {
			f = 10;
			c = 15;
			numM = 30;
			setBounds(700, 100, 501, 480);
		}
		// nivel 3
		else {
			f = 12;
			c = 25;
			numM = 75;
			setBounds(700, 100, 821, 554);
		}
		botones = new JButton[f][c];
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		contentPane.add(getPanelBus(f, c), BorderLayout.CENTER);
		contentPane.add(getPanelSup(), BorderLayout.NORTH);
		this.setVisible(true);
		// A�ado el Observer al tablero
		Buscaminas.getBuscaminas().getablero().addObserver(this);
		// Se ejecuta el cronometro
		crono = new Thread(this);
		crono.start();
	}

	// Panel con todas las casillas dependiendo del nivel, estas las construimes
	// mediante dos for
	private JPanel getPanelBus(int f, int c) {
		panelBus = new JPanel();
		panelBus.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		FlowLayout flowLayout = (FlowLayout) panelBus.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		flowLayout.setHgap(0);
		flowLayout.setVgap(0);

		for (int i = 0; i < f; i++) {
			for (int j = 0; j < c; j++) {
				panelBus.add(getBtnNewButton(i, j));
			}
		}
		return panelBus;
	}

	// Boton que corresponde a cada casilla, lo meto en la matriz
	private JButton getBtnNewButton(int f, int c) {
		casillaB = new JButton();
		casillaB.setMargin(new Insets(23, 13, 8, 13));
		botones[f][c] = casillaB;
		casillaB.addActionListener(new ControladorBotones(f, c));
		casillaB.setActionCommand("descubrir");
		// En caso de pulsar el bot�n derecho del rat�n
		casillaB.addMouseListener(new ControladorDerecho(f, c));
		return casillaB;
	}

	// Panel superior donde ir� la cara para reiniciar el juego
	private JPanel getPanelSup() {
		panelSup = new JPanel();
		panelSup.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panelSup.setBackground(SystemColor.inactiveCaption);
		panelSup.add(btnMenu());
		{
			separador2 = new JLabel("                     ");
			panelSup.add(separador2);
		}
		panelSup.add(getMinasQuedan());
		panelSup.add(carita());
		panelSup.add(getDesveladas());
		{
			separador1 = new JLabel("                     ");
			panelSup.add(separador1);
		}
		panelSup.add(btnRankig());
		// panelSup.add(tiempo);
		// tiempo.setFont(new Font("Tahoma", Font.BOLD, 16));
		return panelSup;
	}

	// La cara para reiniciar el juego
	private JButton carita() {
		carita = new JButton();
		carita.setMargin(new Insets(0, 0, 0, 0));
		carita.setIcon(new ImageIcon(VentanaBuscaminas.class
				.getResource("/imagenes/icono1.jpg")));
		carita.setPressedIcon(new ImageIcon(VentanaBuscaminas.class
				.getResource("/imagenes/icono2.jpg")));
		carita.addActionListener(new ControladorBotones());
		carita.setActionCommand("carita");
		return carita;
	}

	private JButton btnMenu() {
		menu = new JButton();
		menu.setMargin(new Insets(0, 0, 0, 0));
		menu.setIcon(new ImageIcon(VentanaBuscaminas.class
				.getResource("/imagenes/menu.jpg")));
		menu.addActionListener(new ControladorBotones());
		menu.setActionCommand("menu");
		return menu;
	}

	private JButton btnRankig() {
		ranking = new JButton();
		ranking.setMargin(new Insets(0, 0, 0, 0));
		ranking.setIcon(new ImageIcon(VentanaBuscaminas.class
				.getResource("/imagenes/ranking.jpg")));
		ranking.addActionListener(new ControladorBotones());
		ranking.setActionCommand("ranking");
		return ranking;
	}

	// Numero del panel superior que representa el numero de desveladas en juego
	private JLabel getDesveladas() {
		desveladas = new JLabel("00");
		desveladas.setFont(new Font("Tahoma", Font.BOLD, 16));
		return desveladas;
	}

	// Numero del panel superior que representa el numero de minas que quedan
	// por marcar
	private JLabel getMinasQuedan() {
		minasQuedan = new JLabel(String.valueOf(numM));
		minasQuedan.setFont(new Font("Tahoma", Font.BOLD, 16));
		return minasQuedan;
	}

	// Cron�metro para calcular la posici�n en el ranking del jugador
	// int minutos = 0, segundos = 0;

	// public void run() {
	// try {
	// for (;;) {
	// if (segundos == 59) {
	// segundos = 0;
	// minutos++;
	// }
	// if (minutos == 60) {
	// //new DialogPerdido(this, true);
	// }
	// segundos++;
	// tiempo.setText(minutos + ":" + segundos);
	// crono.sleep(1000);
	// }
	// } catch (InterruptedException e) {
	// System.out.println(e.getMessage());
	// }
	// }
	int segundos = 0;
	private JButton volver;
	private JButton ranking;
	private JLabel separador2;
	private JLabel separador1;

	public void run() {
		try {
			for (;;) {
				if (segundos == 600) {
					new DialogPerdido(this, true);
				}
				segundos++;
				// tiempo.setText(" " +segundos);
				crono.sleep(1000);
			}
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
	}

	// Indica el n�mero de marcadas que debe haber
	public void cargarMarcadas() {
		int minasQ = Buscaminas.getBuscaminas().getablero().getNumMinas()
				- Buscaminas.getBuscaminas().getablero().getNumMarcadas();
		minasQuedan.setText(Integer.toString(minasQ));

		if (minasQ < 10 && minasQ >= 0) {
			minasQuedan.setText("0" + Integer.toString(minasQ));
		}
	}

	// Al perder la partida se dibujan todas las minas existentes
	public void pintarMinas(int fila, int columna) {
		for (int f = 0; f < botones.length; f++) {
			for (int c = 0; c < botones[0].length; c++) {
				if (Buscaminas.getBuscaminas().getablero().obtenerCasilla(f, c) instanceof CasillaConMina) {
					ImageIcon iconoOriginal = new ImageIcon(
							VentanaBuscaminas.class
									.getResource("/imagenes/mina.png"));
					ImageIcon iconoEscala = new ImageIcon(iconoOriginal
							.getImage().getScaledInstance(26, 31,
									java.awt.Image.SCALE_DEFAULT));
					botones[f][c].setIcon(iconoEscala);
					botones[f][c].setMargin(new Insets(0, 0, 0, 0));
					botones[f][c].setFocusPainted(false);
					botones[f][c].setContentAreaFilled(false);
				}
			}
		}
	}

	// Actualizamos el numero de casillas descubiertas
	public void updateDesveladas() {
		desveladas.setText("0"
				+ String.valueOf(Buscaminas.getBuscaminas().getablero()
						.getNumDesveladas()));
		if ((Buscaminas.getBuscaminas().getablero().getNumDesveladas()) > 9) {
			desveladas.setText(String.valueOf(Buscaminas.getBuscaminas()
					.getablero().getNumDesveladas()));
		}
	}

	public void recursivoVacias() {
		for (int i = 0; i < botones.length; i++) {
			for (int j = 0; j < botones[0].length; j++) {
				if (Buscaminas.getBuscaminas().obtenerCasilla(i, j)
						.esDercubierta()) {
					// Primero quitamos la banderita, en caso de que tubiese
					if (Buscaminas.getBuscaminas().obtenerCasilla(i, j)
							.esMarcada()) {
						botones[i][j].setIcon(null);
						botones[i][j].setMargin(new Insets(17, 13, 14, 13));
					}
					// Si es una casilla con numero, aparecera el
					// numero de adyacentes
					if (Buscaminas.getBuscaminas().obtenerCasilla(i, j) instanceof CasillaConNumero) {
						botones[i][j].setText(String
								.valueOf(((CasillaConNumero) Buscaminas
										.getBuscaminas().obtenerCasilla(i, j))
										.getNumeroCasillasAdj()));
						botones[i][j]
								.setFont(new Font("Tahoma", Font.PLAIN, 13));
						botones[i][j].setMargin(new Insets(8, 10, 7, 9));
					}
					botones[i][j].setEnabled(false);
				}
			}
		}
	}

	// Obtenemos el numero de minas que quedan
	public void pintarNumero() {
		JButton b = botones[fSelect][cSelect];
		b.setText(String.valueOf(((CasillaConNumero) Buscaminas.getBuscaminas()
				.obtenerCasilla(fSelect, cSelect)).getNumeroCasillasAdj()));
		b.setFont(new Font("Tahoma", Font.PLAIN, 13));
		b.setMargin(new Insets(8, 9, 7, 10));
	}

	// ponemos los botones a invisible
	public void desbilitarBotones() {
		if (fSelect != -1 && cSelect != -1) {
			botones[fSelect][cSelect].setEnabled(false);
		}
	}

	public void verRanking() {
		new VentanaRanking(this, true);
	}

	public int obtenerPuntuacion() {
		int punt = 0;
		int nivel = Sesion.getSesion().getNivel();
		if (segundos <= 60) {
			punt = (1000 * nivel) - (segundos * 10 * nivel);
		} else if (segundos <= 120) {
			punt = (1000 * nivel) - (600 * nivel) - (segundos * 3 * nivel);
		} else if (segundos <= 240) {
			punt = (1000 * nivel) - (600 * nivel) - (180 * nivel)
					- (segundos * nivel);
		} else if (segundos <= 400) {
			punt = (1000 * nivel) - (600 * nivel) - (180 * nivel)
					- (120 * nivel) - (int) (segundos * 0.5 * nivel);
		} else
			punt = 1;
		return punt;
	}

	// El controlador para gestionar los eventos y lo que se debe hacer en caso
	// de que se presione una casilla
	private class ControladorBotones extends WindowAdapter implements
			ActionListener {
		private int fila, columna;

		public ControladorBotones(int pF, int pC) {
			this.fila = pF;
			this.columna = pC;
		}

		public ControladorBotones() {
		}

		@Override
		public void actionPerformed(ActionEvent ae) {
			String action = ae.getActionCommand();
			fSelect = fila;
			cSelect = columna;
			// En caso de pulsar casilla, se descubre la Casilla
			if (action.equals("descubrir")) {
				Sesion.getSesion().setPuntuacion(obtenerPuntuacion());
				Buscaminas.getBuscaminas().descubrirCasilla(fSelect, cSelect);
			}
			// Si se pulsa la carita se reiniciara la partida con el mismo
			// nivel, adem�s sera necerario reiniciar tambi�n la sesi�n
			else if (action.equals("carita")) {
				dispose();
				Sesion.getSesion().actualizarTablero();
				new VentanaBuscaminas(Sesion.getSesion().getNivel());
			} else if (action.equals("menu")) {
				dispose();
				new VentanaInicial();
			} else if (action.equals("ranking")) {
				verRanking();
			}
		}
	}

	// Controlador solo en caso que el usuario pulse bot�n derecho en una de las
	// casillas
	private class ControladorDerecho extends JApplet implements MouseListener {
		int f, c;

		public ControladorDerecho(int pF, int pC) {
			f = pF;
			c = pC;
		}

		@Override
		public void mouseClicked(MouseEvent e) {
			if (e.isMetaDown()) {
				fSelect = f;
				cSelect = c;
				Buscaminas.getBuscaminas().marcarDesmarcarCasilla(fSelect,
						cSelect);
			}
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
		}

		@Override
		public void mouseExited(MouseEvent arg0) {

		}

		@Override
		public void mousePressed(MouseEvent arg0) {

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {

		}
	}

	// El m�todo update
	@Override
	public void update(Observable arg0, Object arg1) {
		if (arg1.equals("marcar")) {
			ImageIcon iconoOriginal = new ImageIcon(
					VentanaBuscaminas.class
							.getResource("/imagenes/banderita.jpe"));
			ImageIcon iconoEscala = new ImageIcon(iconoOriginal.getImage()
					.getScaledInstance(26, 31, java.awt.Image.SCALE_DEFAULT));
			botones[fSelect][cSelect].setIcon(iconoEscala);
			botones[fSelect][cSelect].setMargin(new Insets(0, 0, 0, 0));
			this.cargarMarcadas();
		}

		else if (arg1.equals("desmarcar")) {
			botones[fSelect][cSelect].setIcon(null);
			botones[fSelect][cSelect].setMargin(new Insets(17, 13, 14, 13));
			this.cargarMarcadas();
		} else if (arg1.equals("descubrirVacia")) {
			this.desbilitarBotones();
			this.cargarMarcadas();
			this.updateDesveladas();
			this.cargarMarcadas();
			this.recursivoVacias();
		}

		else if (arg1.equals("descubrirNumero")) {
			this.desbilitarBotones();
			this.cargarMarcadas();
			this.updateDesveladas();
			this.cargarMarcadas();
			this.pintarNumero();
		}

		else if (arg1.equals("perdido")) {
			this.pintarMinas(fSelect, cSelect);
			crono.interrupt();
			new DialogPerdido(this, true);
		}

		else if (arg1.equals("ganado")) {
			GestorBD mibase = new GestorBD();
			if (!mibase.esta(Sesion.getSesion().getJugador().getNombre())) {
				mibase.setNuevoUsuario(Sesion.getSesion().getJugador()
						.getNombre(), this.obtenerPuntuacion(), Sesion
						.getSesion().getNivel());
			} else {
				mibase.setJugadorUpdate(Sesion.getSesion().getJugador()
						.getNombre(), this.obtenerPuntuacion(), Sesion
						.getSesion().getNivel());
			}
			new DialogGanada();
			crono.interrupt();
			dispose();
		}
	}
	
	
}
